main()
{
  printf("Hello, PDP11!\n");
}
